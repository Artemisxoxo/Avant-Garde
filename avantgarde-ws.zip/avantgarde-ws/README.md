# Avant-Garde Wine & Spirits

Website for Avant-Garde Wine & Spirits, New York.

## Stack

- Static HTML / CSS / JS — no framework
- Hosted on Vercel
- Fonts: Playfair Display + DM Sans (Google Fonts)

## Structure

```
avantgarde-ws/
├── index.html          # Main site (all pages, SPA-style)
├── vercel.json         # Vercel config (clean URLs, caching)
├── assets/
│   ├── style.css       # All styles
│   └── images/
│       └── leaf.jpg    # Hero background
└── js/
    └── main.js         # All page logic
```

## Development

No build step. Open `index.html` directly in a browser, or use any static server:

```bash
npx serve .
```

## Deployment

Connected to Vercel via GitHub. Every push to `main` auto-deploys.

## Contact Form

The contact modal currently logs to console.
To wire to email: sign up at formspree.io, create a form, replace the
`submitModal()` function in `js/main.js` with the Formspree fetch call.
Takes ~5 minutes.

## To do

- [ ] Producers page (full editorial layout)
- [ ] National page
- [ ] Client portal with real auth
- [ ] Wire contact form to Formspree
- [ ] Add logo mark / favicon
- [ ] Mobile responsive pass
