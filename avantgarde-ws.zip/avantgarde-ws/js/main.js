function showPage(id,navEl){
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  document.querySelectorAll('.nav-link').forEach(l=>l.classList.remove('active'));
  document.getElementById('page-'+id).classList.add('active');
  if(navEl)navEl.classList.add('active');
  window.scrollTo(0,0);
}
function doLogin(){
  var e=document.getElementById('login-email').value;
  if(!e){alert('Please enter your email.');return;}
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  document.getElementById('page-portal').classList.add('active');
  window.scrollTo(0,0);
}
function switchTab(id,btn){
  document.querySelectorAll('.portal-tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(t=>t.classList.remove('active'));
  if(btn)btn.classList.add('active');
  document.getElementById('tab-'+id).classList.add('active');
}
function setFilter(btn){
  document.querySelectorAll('.filter-pill').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
}
function submitOrder(){
  var el=document.getElementById('order-success');
  el.style.display='block';
  setTimeout(()=>{el.style.display='none'},6000);
}
function footerSubscribe(){
  var e=document.getElementById('footer-email').value;
  if(!e){alert('Please enter your email.');return;}
  var el=document.getElementById('footer-success');
  el.style.display='block';
}
function submitContact(){
  var el=document.getElementById('contact-success');
  el.style.display='block';
  setTimeout(()=>{el.style.display='none'},6000);
}

function openContactModal() {
  document.getElementById('contact-modal').classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeContactModal(e, force) {
  if (force || (e && e.target === document.getElementById('contact-modal'))) {
    document.getElementById('contact-modal').classList.remove('open');
    document.body.style.overflow = '';
    document.getElementById('modal-success').style.display = 'none';
  }
}
function submitModal() {
  var name = document.getElementById('modal-name').value;
  var email = document.getElementById('modal-email').value;
  var subject = document.getElementById('modal-subject').value;
  var message = document.getElementById('modal-message').value;
  if (!name || !email || !subject || !message) {
    alert('Please fill in all fields.');
    return;
  }
  // In production this fires to gducroux@avantgarde-ws.com
  var el = document.getElementById('modal-success');
  el.style.display = 'block';
  setTimeout(function() {
    closeContactModal(null, true);
    document.getElementById('modal-name').value = '';
    document.getElementById('modal-email').value = '';
    document.getElementById('modal-subject').value = '';
    document.getElementById('modal-message').value = '';
  }, 2200);
}